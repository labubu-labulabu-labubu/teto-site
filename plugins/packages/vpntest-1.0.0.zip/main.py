import json, socket, sys
def main():
    act = sys.argv[1] if len(sys.argv) > 1 else "info"
    if act == "info":
        print("联机诊断 v1.0 · 查网络环境的小工具")
        return
    print("== 联机环境自检 ==")
    try:
        host = socket.gethostname()
        ip = socket.gethostbyname(host)
        print("主机名:", host)
        print("内网 IP:", ip)
    except Exception as ex:
        print("主机名解析失败:", ex)
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        s.connect(("2001:db8::1", 80)); s.close()
        print("IPv6: 可用")
    except Exception:
        print("IPv6: 不可用（不影响同一 Wi-Fi 联机）")
    print("提示: 同一个 Wi-Fi 直接进房；不同网络要两边都有 IPv6")
if __name__ == "__main__":
    main()
