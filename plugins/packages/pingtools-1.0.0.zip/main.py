import sys
DATA = [
    ("本地开服", "127.0.0.1:25565", "同一台机器上自己连"),
    ("局域网", "192.168.x.x:25565", "同一个 Wi-Fi 下进房"),
    ("火腿服", "hypixel.net", "国际大型小游戏服"),
    ("陶瓦联机", "房间号", "启动器内置，填名字建房"),
]
def main():
    act = sys.argv[1] if len(sys.argv) > 1 else "info"
    if act == "info":
        print("地址速查 v1.0 · 常用联机地址与端口")
        return
    print("== 常用地址 ==")
    for name, addr, note in DATA:
        print("%-8s %-24s %s" % (name, addr, note))
    print("\n端口 25565 是 MC 默认端口，改过端口要在地址后加 :端口号")
if __name__ == "__main__":
    main()
