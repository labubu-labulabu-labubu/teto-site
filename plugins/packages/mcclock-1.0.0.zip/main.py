import time, sys
def main():
    act = sys.argv[1] if len(sys.argv) > 1 else "info"
    if act == "info":
        print("MC 时钟 v1.0 · 把现实时间换算成游戏里的昼光")
        return
    tick = (time.time() / 1000) % 1
    # MC: 0=日出 0.25=正午 0.5=日落 0.75=午夜
    if 0 <= tick < 0.25: phase = "早晨 → 正午"
    elif 0.25 <= tick < 0.5: phase = "正午 → 黄昏"
    elif 0.5 <= tick < 0.75: phase = "黄昏 → 夜晚"
    else: phase = "深夜 → 日出"
    print("游戏时间光照: %.0f%%" % (tick * 100))
    print("现在大概:", phase)
    print("游戏一天 = 现实 20 分钟，白天 10 分钟、黑夜 7 分钟、黄昏黎明各 1.5 分钟")
if __name__ == "__main__":
    main()
