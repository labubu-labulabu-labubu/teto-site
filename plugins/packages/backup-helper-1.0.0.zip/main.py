import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    args = sys.argv[2:]
    if args and args[0] == "do":
        if len(args) < 2:
            print("用法：backup-helper do <世界名>")
            return
        name = args[1]
        r = api.backup(name)
        print(r if r else "备份失败，检查世界名对不对")
        return
    rows = api.saves()
    if not rows:
        print("还没有本地存档，不用备份。")
        return
    rows.sort(key=lambda x: x["size"], reverse=True)
    print("== 最值得备份的世界（按大小）==")
    for r in rows[:10]:
        print("  %s  %s  %s" % (r["name"], api.human_size(r["size"]), r["time"]))
    print("\n备份命令在启动器「存档备份」页面点一下就行。")
if __name__ == "__main__":
    main()
