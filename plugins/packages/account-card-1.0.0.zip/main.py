import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    a = api.account()
    kind = a.get("类型", "离线")
    print("== 我的身份卡 ==")
    print("名字：%s" % a.get("名字", "?"))
    print("类型：%s" % kind)
    print("有效：%s" % ("是" if a.get("有效") == "1" else "否"))
    cloud = kind.find("云") >= 0
    print("云同步：%s" % ("可用，存档和手机通用" if cloud else "不可用（登录云账号后可用）"))
    if not cloud:
        print("\n在「账号」里登录云账号，就能和手机端互通存档。")
if __name__ == "__main__":
    main()
