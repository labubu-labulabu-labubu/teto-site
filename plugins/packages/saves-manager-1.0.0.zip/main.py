import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    rows = api.saves()
    if not rows:
        print("没有找到本地存档。先进游戏建个世界吧。")
        return
    rows.sort(key=lambda x: x["size"], reverse=True)
    total = sum(r["size"] for r in rows)
    print("== 本地世界存档（共 %d 个，合计 %s）==" % (len(rows), api.human_size(total)))
    for i, r in enumerate(rows[:30], 1):
        print("%2d. %s  %s  %d 个文件  %s" % (
            i, r["name"], api.human_size(r["size"]), r["files"], r["time"]))
    if len(rows) > 30:
        print("… 还有 %d 个没列出来" % (len(rows) - 30))
    print("\n提示：想备份某个世界，用「存档备份」插件。")
if __name__ == "__main__":
    main()
