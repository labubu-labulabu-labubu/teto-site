import random, sys
COLORS = ["ff0000","00ff00","0000ff","ffcc00","ff00ff","00ffff","ffffff","222222"]
def main():
    act = sys.argv[1] if len(sys.argv) > 1 else "info"
    if act == "info":
        print("随机皮肤 v1.0.1 · 一键生成配色灵感")
        return
    times = 5
    if len(sys.argv) > 2:
        try: times = max(1, min(20, int(sys.argv[2])))
        except ValueError: pass
    for i in range(times):
        body = "#" + random.choice(COLORS)
        legs = "#" + random.choice(COLORS)
        print("方案%d  身体%s  裤腿%s" % (i + 1, body, legs))
if __name__ == "__main__":
    main()
