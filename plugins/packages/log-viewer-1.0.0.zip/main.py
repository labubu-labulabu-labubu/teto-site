import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    n = 40
    args = sys.argv[2:]
    if args:
        try: n = max(5, min(300, int(args[0])))
        except ValueError: pass
    lines = api.log(n)
    if not lines:
        print("日志是空的。")
        return
    print("== 最近 %d 行日志 ==" % len(lines))
    for line in lines:
        print(line)
if __name__ == "__main__":
    main()
