import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    s = api.stats()
    acc = api.account()
    print("== 我的游玩报告 ==")
    print("玩家：%s（%s）" % (acc.get("名字", "?"), acc.get("类型", "?")))
    print("总游玩：%s" % s.get("总游玩", "—"))
    print("启动次数：%s" % s.get("启动次数", "0"))
    print("上次游玩：%s" % s.get("上次游玩", "—"))
    print("最近版本：%s" % (s.get("最近版本") or "—"))
    print("\n已装 %s 个版本，%s 个存档，%s 个模组" % (
        s.get("已装版本", "0"), s.get("存档数", "0"), s.get("模组数", "0")))
    print("（数据来自启动器真实记录）")
if __name__ == "__main__":
    main()
