import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    acc = api.account()
    if acc.get("类型", "").find("云") < 0:
        print("你现在不是云账号（当前：%s）。" % acc.get("类型", "离线"))
        print("在启动器「账号」里登录/注册云账号后，手机电脑存档就能通用。")
        return
    cloud_rows = api.cloud_saves()
    local_names = set(r["name"] for r in api.saves())
    cloud_names = set(r["name"] for r in cloud_rows)
    print("== 云同步状态（账号：%s）==" % acc.get("名字", ""))
    print("云上 %d 个存档，本地 %d 个世界" % (len(cloud_rows), len(local_names)))
    not_up = sorted(local_names - cloud_names)
    not_down = sorted(cloud_names - local_names)
    both = sorted(local_names & cloud_names)
    if not_up:
        print("\n还没传到云的（%d 个）：" % len(not_up))
        for n in not_up[:15]:
            print("  ↑ " + n)
    if not_down:
        print("\n云上有、本地没有的（%d 个，可下载）：" % len(not_down))
        for n in not_down[:15]:
            print("  ↓ " + n + "  " + api.human_size(
                next((r["size"] for r in cloud_rows if r["name"] == n), 0)))
    if both:
        print("\n两边都有的（%d 个）：%s" % (len(both), ", ".join(both[:8])))
    if not not_up and not not_down:
        print("\n两边已经同步好了。")
    print("\n上传/下载在「云存档」页面操作。")
if __name__ == "__main__":
    main()
