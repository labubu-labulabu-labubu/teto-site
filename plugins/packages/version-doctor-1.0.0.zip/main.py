import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    vs = api.versions()
    installed = [v for v in vs if v["installed"]]
    local = [v for v in installed if v["local_only"]]
    mods = sum(v["mods"] for v in installed)
    print("== 版本体检 ==")
    print("列表里 %d 个版本，已装 %d 个" % (len(vs), len(installed)))
    print("已装版本模组总数：%d" % mods)
    types = {}
    for v in installed:
        types[v["type"]] = types.get(v["type"], 0) + 1
    if types:
        print("按类型：" + "  ".join("%s %d" % (k, n) for k, n in types.items()))
    if local:
        print("\n本地独有（没在官方列表，删前想清楚）：")
        for v in local[:20]:
            print("  · " + v["id"])
    top = sorted(installed, key=lambda x: x["mods"], reverse=True)[:5]
    if top:
        print("\n模组最多的 5 个版本：")
        for v in top:
            print("  %s  %d 个模组" % (v["id"], v["mods"]))
if __name__ == "__main__":
    main()
