import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    args = sys.argv[2:]
    q = args[0] if args else "sodium"
    kind = args[1] if len(args) > 1 else "mod"
    rows = api.search(q, kind)
    if not rows:
        print("没搜到「%s」，或者网络不通。" % q)
        return
    print("== 搜「%s」(%s)，%d 条 ==" % (q, kind, len(rows)))
    for r in rows[:15]:
        print("  · " + " | ".join(str(x) for x in r[:4]))
    print("\n详细安装去启动器「资源中心」。")
if __name__ == "__main__":
    main()
