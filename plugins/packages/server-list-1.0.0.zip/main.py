import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    rows = api.servers()
    if not rows:
        print("还没有保存的服务器。在启动器里加一个吧。")
        return
    print("== 服务器清单（%d 个）==" % len(rows))
    for r in rows[:30]:
        print("  · " + " | ".join(str(x) for x in r[:5]))
    print("\n同一个 Wi-Fi 可以直接进房；不同网络要两边都有 IPv6 或用陶瓦联机。")
if __name__ == "__main__":
    main()
