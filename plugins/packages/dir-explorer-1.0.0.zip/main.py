import sys
from core import plugin_api as api

def act():
    return sys.argv[1] if len(sys.argv) > 1 else "info"


def main():
    d = api.dirs()
    if not d:
        print("读不到目录信息。")
        return
    names = {"mc": "游戏根目录", "versions": "版本", "mods": "模组",
             "saves": "存档", "resourcepacks": "材质包", "data": "启动器数据",
             "servers": "服务器列表", "logs": "日志"}
    print("== 目录速查 ==")
    for k, label in names.items():
        if k in d:
            v = d[k]
            print("%s：%s" % (label, v["path"]))
    print("\n（有版本 %d/%d，缺的目录用的时候会自动建）" % (
        sum(1 for v in d.values() if v["exists"]), len(d)))
if __name__ == "__main__":
    main()
